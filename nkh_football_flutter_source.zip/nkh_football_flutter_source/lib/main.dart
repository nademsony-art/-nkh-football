
import 'package:flutter/material.dart';

void main() => runApp(const NkhFootballApp());

const Color gold = Color(0xFFD8B15C);
const Color pageBg = Color(0xFF0D0E11);
const Color panel = Color(0xFF191B20);
const Color muted = Color(0xFF9EA2AB);

class NkhFootballApp extends StatelessWidget {
  const NkhFootballApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NKH FOOTBALL',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: pageBg,
        colorScheme: const ColorScheme.dark(
          primary: gold,
          secondary: gold,
          surface: panel,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: pageBg,
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: panel,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFF343740)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFF343740)),
          ),
        ),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: MainShell(),
      ),
    );
  }
}

class Team {
  Team(this.name, {this.city = 'غير محدد', this.players = 0});
  final String name;
  final String city;
  final int players;
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selectedIndex = 0;
  final List<Team> teams = [
    Team('نسور الساحل', city: 'اللاذقية', players: 11),
    Team('صقور الشام', city: 'طرطوس', players: 9),
    Team('فرسان المدينة', city: 'دمشق', players: 12),
  ];

  void addTeam() async {
    final nameController = TextEditingController();
    final cityController = TextEditingController();
    final result = await showDialog<Team>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: panel,
        title: const Text('إنشاء فريق جديد'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'اسم الفريق'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: cityController,
              decoration: const InputDecoration(labelText: 'المدينة'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.black),
            onPressed: () {
              final name = nameController.text.trim();
              if (name.isNotEmpty) {
                Navigator.pop(
                  context,
                  Team(name, city: cityController.text.trim().isEmpty ? 'غير محدد' : cityController.text.trim()),
                );
              }
            },
            child: const Text('إنشاء'),
          ),
        ],
      ),
    );
    if (result != null) {
      setState(() => teams.add(result));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تمت إضافة الفريق إلى القائمة التجريبية')),
      );
    }
    nameController.dispose();
    cityController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(teamCount: teams.length, onOpenTournaments: () => setState(() => selectedIndex = 3)),
      TeamsPage(teams: teams, onAdd: addTeam),
      const MatchesPage(),
      const TournamentsPage(),
      const ProfilePage(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text('N.K.H WORLD', style: TextStyle(color: gold, fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.bold)),
            SizedBox(height: 3),
            Text('NKH FOOTBALL', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'الإشعارات',
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('لا توجد إشعارات جديدة')),
            ),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
        ],
      ),
      body: SafeArea(child: pages[selectedIndex]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF15161A),
        indicatorColor: gold.withOpacity(.18),
        selectedIndex: selectedIndex,
        onDestinationSelected: (index) => setState(() => selectedIndex = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.shield_outlined), selectedIcon: Icon(Icons.shield), label: 'الفرق'),
          NavigationDestination(icon: Icon(Icons.sports_soccer_outlined), selectedIcon: Icon(Icons.sports_soccer), label: 'المباريات'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events), label: 'البطولات'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.teamCount, required this.onOpenTournaments});
  final int teamCount;
  final VoidCallback onOpenTournaments;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: const LinearGradient(colors: [Color(0xFF29251B), Color(0xFF17181C)]),
            border: Border.all(color: gold.withOpacity(.35)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text('REAL FOOTBALL.', style: TextStyle(color: gold, fontSize: 13, letterSpacing: 2, fontWeight: FontWeight.bold)),
              Text('REAL COMPETITION.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              SizedBox(height: 8),
              Text('منصة كرة القدم للهواة في سوريا', style: TextStyle(color: muted)),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const SectionTitle('نظرة عامة'),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 1.65,
          children: [
            StatCard(label: 'الفرق في هذه النسخة', value: '$teamCount', icon: Icons.shield),
            const StatCard(label: 'المباريات المكتملة', value: '24', icon: Icons.sports_soccer),
            const StatCard(label: 'البطولات النشطة', value: '2', icon: Icons.emoji_events),
            const StatCard(label: 'أهداف الهداف', value: '12', icon: Icons.sports),
          ],
        ),
        const SizedBox(height: 20),
        const SectionTitle('أحدث النتائج'),
        const MatchTile(home: 'نسور الساحل', away: 'صقور الشام', score: '3 - 1', status: 'منتهية'),
        const SizedBox(height: 18),
        const SectionTitle('البطولة القادمة'),
        CardPanel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(children: [Expanded(child: Text('كأس NKH — 8 فرق', style: TextStyle(fontWeight: FontWeight.bold))), StatusPill('التسجيل مفتوح')]),
              const SizedBox(height: 8),
              const Text('مجموعتان • ذهاب وإياب • نصف نهائي ونهائي', style: TextStyle(color: muted, fontSize: 12)),
              const SizedBox(height: 14),
              const Text('اشتراك الفريق: 300,000 ل.س', style: TextStyle(color: gold, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerLeft,
                child: OutlinedButton(onPressed: onOpenTournaments, child: const Text('عرض البطولات')),
              ),
            ],
          ),
        ),
        const DemoNotice(),
      ],
    );
  }
}

class TeamsPage extends StatelessWidget {
  const TeamsPage({super.key, required this.teams, required this.onAdd});
  final List<Team> teams;
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            const Expanded(child: SectionTitle('الفرق المسجلة')),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.black),
              onPressed: onAdd,
              icon: const Icon(Icons.add),
              label: const Text('إنشاء فريق'),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ...teams.map((team) => CardPanel(
          child: Row(
            children: [
              const Crest(),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(team.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text('${team.city} • ${team.players} لاعب', style: const TextStyle(color: muted, fontSize: 12)),
                ]),
              ),
              const StatusPill('نشط'),
            ],
          ),
        )),
        const DemoNotice(),
      ],
    );
  }
}

class MatchesPage extends StatelessWidget {
  const MatchesPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: const [
      SectionTitle('المباريات'),
      MatchTile(home: 'نسور الساحل', away: 'صقور الشام', score: '3 - 1', status: 'منتهية'),
      MatchTile(home: 'فرسان المدينة', away: 'نجوم حلب', score: '—', status: 'قادمة'),
      MatchTile(home: 'شباب اللاذقية', away: 'أسود حمص', score: '—', status: 'مجدولة'),
      DemoNotice(),
    ],
  );
}

class TournamentsPage extends StatelessWidget {
  const TournamentsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const SectionTitle('البطولات'),
      CardPanel(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(children: [Expanded(child: Text('كأس NKH — 8 فرق', style: TextStyle(fontWeight: FontWeight.bold))), StatusPill('التسجيل مفتوح')]),
          const SizedBox(height: 10),
          const Text('مجموعتان، في كل مجموعة 4 فرق. ذهاب وإياب في المجموعات، ثم نصف النهائي والنهائي.', style: TextStyle(color: muted, height: 1.5)),
          const Divider(height: 24),
          const InfoRow('اشتراك الفريق', '300,000 ل.س'),
          const InfoRow('المباريات الإجمالية', '27 مباراة'),
          const InfoRow('مباريات المجموعات لكل فريق', '6 مباريات'),
          const SizedBox(height: 12),
          SizedBox(width: double.infinity, child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.black),
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('التسجيل غير متاح في النسخة التجريبية'))),
            child: const Text('تفاصيل التسجيل'),
          )),
        ]),
      ),
      CardPanel(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
          Row(children: [Expanded(child: Text('بطولة NKH — 16 فريقاً', style: TextStyle(fontWeight: FontWeight.bold))), StatusPill('قريباً')]),
          SizedBox(height: 10),
          Text('4 مجموعات • ذهاب وإياب • ربع نهائي ونصف نهائي ذهاب وإياب • نهائي من مباراة واحدة', style: TextStyle(color: muted, height: 1.5)),
          Divider(height: 24),
          InfoRow('اشتراك الفريق', '350,000 ل.س'),
          InfoRow('المباريات الإجمالية', '61 مباراة'),
        ]),
      ),
      const DemoNotice(),
    ],
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: const [
      SectionTitle('حساب اللاعب'),
      CardPanel(child: Column(children: [
        CircleAvatar(radius: 34, backgroundColor: Color(0xFF302819), child: Icon(Icons.person, color: gold, size: 38)),
        SizedBox(height: 12),
        Text('لاعب تجريبي', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        SizedBox(height: 4),
        Text('عضو في NKH FOOTBALL', style: TextStyle(color: muted, fontSize: 12)),
        Divider(height: 28),
        InfoRow('الفريق', 'نسور الساحل'),
        InfoRow('المباريات', '6'),
        InfoRow('الأهداف', '4'),
      ])),
      DemoNotice(),
    ],
  );
}

class StatCard extends StatelessWidget {
  const StatCard({super.key, required this.label, required this.value, required this.icon});
  final String label, value;
  final IconData icon;
  @override
  Widget build(BuildContext context) => CardPanel(
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Icon(icon, color: gold, size: 20),
      Text(value, style: const TextStyle(color: gold, fontSize: 25, fontWeight: FontWeight.w900)),
      Text(label, style: const TextStyle(color: muted, fontSize: 11)),
    ]),
  );
}

class MatchTile extends StatelessWidget {
  const MatchTile({super.key, required this.home, required this.away, required this.score, required this.status});
  final String home, away, score, status;
  @override
  Widget build(BuildContext context) => CardPanel(
    child: Column(children: [
      Row(children: [const Icon(Icons.sports_soccer, color: gold, size: 17), const SizedBox(width: 7), const Text('مباراة'), const Spacer(), StatusPill(status)]),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(child: Text(home, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold))),
        Text(score, style: const TextStyle(color: gold, fontSize: 22, fontWeight: FontWeight.w900)),
        Expanded(child: Text(away, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold))),
      ]),
    ]),
  );
}

class CardPanel extends StatelessWidget {
  const CardPanel({super.key, required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF2C2F36))),
    child: child,
  );
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
  );
}

class StatusPill extends StatelessWidget {
  const StatusPill(this.text, {super.key});
  final String text;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
    decoration: BoxDecoration(color: gold.withOpacity(.10), borderRadius: BorderRadius.circular(30), border: Border.all(color: gold.withOpacity(.35))),
    child: Text(text, style: const TextStyle(color: gold, fontSize: 10, fontWeight: FontWeight.bold)),
  );
}

class Crest extends StatelessWidget {
  const Crest({super.key});
  @override
  Widget build(BuildContext context) => Container(
    width: 46, height: 46,
    decoration: BoxDecoration(color: const Color(0xFF302819), borderRadius: BorderRadius.circular(13)),
    child: const Icon(Icons.shield, color: gold),
  );
}

class InfoRow extends StatelessWidget {
  const InfoRow(this.label, this.value, {super.key});
  final String label, value;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(children: [
      Expanded(child: Text(label, style: const TextStyle(color: muted, fontSize: 12))),
      Text(value, style: const TextStyle(color: gold, fontWeight: FontWeight.bold, fontSize: 12)),
    ]),
  );
}

class DemoNotice extends StatelessWidget {
  const DemoNotice({super.key});
  @override
  Widget build(BuildContext context) => const Padding(
    padding: EdgeInsets.only(top: 10, bottom: 16),
    child: Text('نسخة أولية تجريبية ببيانات محلية افتراضية. لا يوجد تسجيل دخول أو خادم أو دفع حقيقي بعد.', style: TextStyle(color: muted, fontSize: 11, height: 1.5)),
  );
}
